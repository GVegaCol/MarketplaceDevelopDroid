package com.angee.developdroidmarket

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class list : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
    }
}