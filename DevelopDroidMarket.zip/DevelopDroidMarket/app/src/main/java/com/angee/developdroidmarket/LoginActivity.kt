package com.angee.developdroidmarket

import android.accounts.Account
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.facebook.CallbackManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.ktx.Firebase


class LoginActivity : AppCompatActivity() {

    private var emailEditText: EditText? = null
    private var passwordEditTex: EditText? = null

    private val GOOGLE_SING_IN = 100
    private val callbackManager = CallbackManager.Factory.create()



    override fun onCreate(savedInstanceState: Bundle?) {
        Thread.sleep(2000)
        setTheme(R.style.Theme_DevelopDroidMarket)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

    val prefs=getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
        prefs.putString("email", emailEditText.toString())
        prefs.apply()

        val analytics = FirebaseAnalytics.getInstance(this)
        val bundle = Bundle()
        bundle.putString(
            "Firebase",
            "Firebase"
        )
        analytics.logEvent("Godevelopdroidmarket", bundle)

    }


    fun onAccount(btnRegistro: android.view.View) {
        val intento = Intent(this, Form::class.java)
        startActivity(intento)
    }

    fun onCreate(view: android.view.View) {}

    fun OnLogin(SingUpButton: android.view.View) {
        fun OnLogin(SingUpButton: android.view.View) {
            if (emailEditText!!.text.toString() == "johannacanon@gmail.com") {
                if (passwordEditTex!!.text.toString() == "Vamp5678-") {
                    val intento = Intent(this, list::class.java)
                    startActivity(intento)
                }
            }
        }


                        }

    fun OnGoogle(view: android.view.View) {}

}





    fun OnGoogle(view: android.view.View) {}


